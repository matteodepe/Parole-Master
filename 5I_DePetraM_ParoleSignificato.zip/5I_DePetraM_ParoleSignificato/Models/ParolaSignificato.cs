public class ParolaSignificato {

    public int ParolaSignificatoID { get; set; }

    public string ParolaDomanda { get; set; }
    public string RispostaCorretta {get; set; }

    public string RispostaSbagliataUno {get; set; }

    public string RispostaSbagliataDue {get; set; }

    public string RispostaSbagliataTre { get; set; }

}