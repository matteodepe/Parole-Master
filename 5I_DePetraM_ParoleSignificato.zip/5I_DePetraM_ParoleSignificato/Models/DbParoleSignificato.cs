using Microsoft.EntityFrameworkCore;

public class DbParoleSignificato : DbContext
{
    public DbSet<ParolaSignificato> ParoleSignificato { get; set; }

    public DbParoleSignificato(DbContextOptions<DbParoleSignificato> options) : base(options)
    {

    }

}