﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _5I_DePetraM_ParoleSignificato.Migrations
{
    public partial class CreazioneDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ParoleSignificato",
                columns: table => new
                {
                    ParolaSignificatoID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    RispostaCorretta = table.Column<string>(type: "TEXT", nullable: true),
                    RispostaSbagliataUno = table.Column<string>(type: "TEXT", nullable: true),
                    RispostaSbagliataDue = table.Column<string>(type: "TEXT", nullable: true),
                    RispostaSbagliataTre = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParoleSignificato", x => x.ParolaSignificatoID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ParoleSignificato");
        }
    }
}
