const BASE_URL = "HTTP://localhost:5147/api/ParoleSignificato/Random";
let rispostaGiusta;

function nuovaDomanda() {
    fetch(BASE_URL)
    .then(x => x.json())
    .then(response => {
        document.querySelector("#question").innerText = response["parolaDomanda"];
        rispostaGiusta = response["rispostaCorretta"];
        
        
        let options = [response["rispostaCorretta"], response["rispostaSbagliataUno"], response["rispostaSbagliataDue"], response["rispostaSbagliataTre"]];
        options = options.sort(x => 0.5 - Math.random());

        document.querySelector("#opz1").innerText = options[0];
        document.querySelector("#opz1").disabled = false;
        document.querySelector("#opz2").innerText = options[1];
        document.querySelector("#opz2").disabled = false;
        document.querySelector("#opz3").innerText = options[2];
        document.querySelector("#opz3").disabled = false;
        document.querySelector("#opz4").innerText = options[3];
        document.querySelector("#opz4").disabled = false;
        document.querySelector("#next-button").disabled = false;

    })
    .catch(e => {
        console.log(e);
        new Alert("warning", "Errore di connessione", true, document.body);
        document.querySelector("#opz1").disabled = true;
        document.querySelector("#opz2").disabled = true;
        document.querySelector("#opz3").disabled = true;
        document.querySelector("#opz4").disabled = true;
        document.querySelector("#next-button").disabled = true;
    });
}


this.onload = function() {
    nuovaDomanda();
}

function rispondi(answer) {
    let correct = rispostaGiusta == answer;
    let alert = new Alert(correct ? "success" : "error", correct ? "Hai indovinato!" : "Hai sbagliato! La risposta corretta era '" + rispostaGiusta + "'", true, document.body);
    alert.onclickEvent = nuovaDomanda;
}
