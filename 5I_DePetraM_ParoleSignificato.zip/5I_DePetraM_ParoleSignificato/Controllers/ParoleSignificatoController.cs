using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;


namespace _5I_DePetraM_ParoleSignificato.Controllers;

[ApiController]
[EnableCors("MyPolicy")]
[Route("api/[controller]")]
public class ParoleSignificatoController : ControllerBase
{

    private readonly DbParoleSignificato _context;

    public ParoleSignificatoController(DbParoleSignificato context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ParolaSignificato>>> GetParoleSignificato() {
        return await _context.ParoleSignificato.ToListAsync();
    }

    [HttpGet("Random")]
    public async Task<ActionResult<ParolaSignificato>> GetParolaSignificato() {
        List<ParolaSignificato> parole = await _context.ParoleSignificato.ToListAsync();
        return parole.OrderBy(o => Guid.NewGuid()).First();
    }

}
